#!/bin/bash
tar -czf myhome_directory.tar.gz /Users/Young/learnbash
